import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemServiceService } from '../item-service.service';
@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit { constructor(private router:Router ,private service:ItemServiceService) {
  this.LoadItem();
 }
 itemdata:any;

 ngOnInit(): void {
  
}

  LoadItem() {
    this.service.LoadItem().subscribe((data: any)=>{
      this.itemdata=data;
    });  }  
  
ObjSampleForm:FormGroup=new FormGroup(
  { 
    name:new FormControl('',[Validators.required]),
    description:new FormControl('',[Validators.required]),
    types:new FormControl('',[Validators.required])
    
  }
)

onSubmit(){
  console.log("aaaa");
   
    this.service.addItem(this.ObjSampleForm.value).subscribe(result=>{
      console.log(result);
      if(result.itemId){  
        console.log(result);
        alert("Item added");
      }
      else{
        alert("Item Not added");
      }
    })
 }


 deleteItem(data:any){
  console.log(data);
  this.service.delete(data).subscribe({next:(res:any)=>{
    console.log(res);
  },
  error:(error:any)=>{console.log(console.error);
 }
 });
 }





 


}
