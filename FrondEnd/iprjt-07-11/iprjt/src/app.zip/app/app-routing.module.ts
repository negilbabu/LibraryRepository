import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { BodyComponent } from './body/body.component';
import { UserRegComponent } from './user-reg/user-reg.component';
import { ItemComponent } from './item/item.component';
import { UserserviceService } from './userservice.service';
import { HttpClientModule,HttpHeaders } from '@angular/common/http';

const routes: Routes = [
  {path: '',redirectTo:'login',pathMatch:'full'},
  {path : 'login',component:LoginComponent},
  {path: 'body',component:BodyComponent},
  {path: 'user-reg',component:UserRegComponent},
  {path : 'item',component:ItemComponent}

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
