import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ItemServiceService {
  apiurl='http://localhost:8080';
  accesstocken:any

  constructor(private http:HttpClient) { }

getItemId(data:any){
  return this.http.get('http://localhost:8080/items')
}

addItem(data:any):Observable<any>{
  return this.http.post('http://localhost:8080/items',data)
}


LoadItem(){
  return this.http.get('http://localhost:8080/items');
}

delete(id:any){
  return this.http.delete(this.apiurl+'/items/'+id);
}


getitem(id: any) {
  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Contacts ' + localStorage.getItem('token')
    })
  }
  return this.http.get(this.apiurl + "/items/" + id, httpOptions)
}


// delete(data: number) {
//   const httpOptions = {
//     headers: new HttpHeaders({
//       'Authorization': 'Contacts ' + localStorage.getItem('token')
//     })
//   }
//   return this.http.delete(this.apiurl + '/items/' + data, httpOptions)
// }


}
