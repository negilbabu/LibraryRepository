import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router,Route } from '@angular/router';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-user-reg',
  templateUrl: './user-reg.component.html',
  styleUrls: ['./user-reg.component.css']
})
export class UserRegComponent implements OnInit {
  constructor(private router:Router ,private service:UserserviceService) { }
  
  
  
  ObjSampleForm:FormGroup=new FormGroup(
    { 
      name:new FormControl('',[Validators.required]),
      email:new FormControl('',[Validators.required]),
      password:new FormControl('',[Validators.required])
      
    }
  )

  ngOnInit(): void {
  }


  onSubmit(){
    console.log("aaaa");
    //debugger
   //if(this.ObjSampleForm.valid){
     
      this.service.add(this.ObjSampleForm.value).subscribe(result=>{
        if(result.userId){  
          console.log(result);
          alert("User added");
        }
        else{
          alert("User Not added");
        }
      })
   // }
   }

  


  // onSignUp(){

  //   this.router.navigate(['/user-reg'])

  // }

}
