import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup,Validators } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  responsedata: any;

  constructor(private router:Router, private service:UserserviceService )
   { 
    }
  
  
  
  ObjSampleForm:FormGroup=new FormGroup(
    { 
      email:new FormControl('',[Validators.required]),
      password:new FormControl('',[Validators.required])
      
    }
  )

  ngOnInit(): void {
  }


  onSubmit(){

    //  if(this.ObjSampleForm.valid){
        this.service.login(this.ObjSampleForm.value).subscribe(result=>{
          if(result.userId){
            this.responsedata=result
            console.log(result);
            localStorage.setItem('token',this.responsedata.accessToken.value)
            alert("login sucessful");
            this.router.navigate(['/body'])
          }
          
          else{
            alert("login not sucessful");
          }
        })
    //  }
     
       
   // }
   // else{   
   //       return;
     //   }
  }


  onSignUp(){

    this.router.navigate(['/user-reg'])

  }

}
