package com.innovature.Library.entity;

public @interface Id {

}
