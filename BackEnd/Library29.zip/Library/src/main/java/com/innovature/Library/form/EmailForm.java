package com.innovature.Library.form;

public class EmailForm {
    public String sentto;

    public String getSentto() {
        return sentto;
    }

    public void setSentto(String sentto) {
        this.sentto = sentto;
    }
}
