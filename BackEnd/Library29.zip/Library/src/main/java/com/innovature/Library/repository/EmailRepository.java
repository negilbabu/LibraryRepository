package com.innovature.Library.repository;

import java.util.Collection;

import org.springframework.data.repository.Repository;


public class EmailRepository {



}
