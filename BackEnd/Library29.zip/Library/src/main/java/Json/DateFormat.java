package Json;

public @interface DateFormat {

}
