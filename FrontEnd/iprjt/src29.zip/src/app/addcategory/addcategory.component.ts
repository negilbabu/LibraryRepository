import { Component, OnInit } from '@angular/core';
import { CategoryComponent } from '../category/category.component';
import { MatDialog,MatDialogRef, MatDialogModule} from '@angular/material/dialog';
import { MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { CategoryService } from '../category.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit  {

  categoryList: any[];
  categoryId:any;
  categorydata:any;
  // flag:string="ONE";


  data: any;
page:number=1;
count: any;
tableSize: number = 5;
ProdData: any;
sortedData: any;
a:any;
b:any;
searchResult:any
searchData:any
sort:string="auther";
len: any;
result: any;
  booksCount: any;
  direction=-1;
  constructor(private dialog: MatDialog,private router:Router ,private service:CategoryService) {
    this.categoryList=[];
    
   }

   ngOnInit(): void {

    this.LoadCategory();  
    localStorage.removeItem('categoryId'); 
  }

  LoadCategory() {
    this.service.LoadCategory().subscribe((data: any)=>{
    this.categorydata=data;
    console.log(data)
    })
    ;  }  


  handleError(err: HttpErrorResponse){
      console.log('hhhii',err);
      if ( err.status === 403) {
        alert("UNAUTHORIZED ACCESS DETECTED")
          this.router.navigateByUrl(`/login`);    }
  }

  sortfn(a:any){    
    this.sort=a;      
    this.page=this.page;
    this.tableSize;
  
    if(this.direction==1){
      this.direction=-1;
      console.log("from desc to :",this.direction)
      this.ngOnInit();       
    }
  
    else{
      this.direction=1;
      console.log("from asc to desc",this.direction)
    this.ngOnInit(); 
    }
    
  }

  onTableDataChange(event:any) {
  
    console.log("page=",event)
      this.service.CatPageAdmin(this.page,this.tableSize,this.sort,this.direction).subscribe(result=>{
        this.result=result.content;
        this.count=result.totalElements
        console.log("loaded books=",this.result);   
        this.data=this.result;   
        this.categorydata=this.result;                     
          })       
    }
  

openDialog() {

  const dialogConfig = new MatDialogConfig();
  this.dialog.open(CategoryComponent, dialogConfig);

}

editCategory(categoryId:any) {
 // localStorage.setItem('flag',this.flag);
  localStorage.setItem('categoryId',categoryId);
  const dialogConfig = new MatDialogConfig();
  this.dialog.open(CategoryComponent, dialogConfig);

}




deleteCategory(categoryId:any): void{
  if(confirm('Are you sure want to delete?'))
  {
 console.log(categoryId);
  this.service.delete(categoryId.categoryId).subscribe({next:(res)=>{
    console.log(res);
    alert("item deleted");
    window.location.reload();
  },
  error:(msg)=>{}      
  })
 }
 else{
  this.router.navigate(['/addcategory'])
 }
}














 }
