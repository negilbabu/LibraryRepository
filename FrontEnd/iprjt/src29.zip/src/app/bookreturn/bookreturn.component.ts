import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookreturn',
  templateUrl: './bookreturn.component.html',
  styleUrls: ['./bookreturn.component.css']
})
export class BookreturnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
